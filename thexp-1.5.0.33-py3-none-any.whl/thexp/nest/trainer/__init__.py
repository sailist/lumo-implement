"""
Trainer mixin classes.
"""