"""


    该部份目前仍然在完善中，用于提供面向各种用途的对 torch 中的向量操作或其他数值运算的高级封装
"""

from . import schedule
