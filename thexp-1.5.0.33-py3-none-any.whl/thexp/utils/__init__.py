"""

"""


from .paths import home_dir
from .timing import timeit
from .screen import ScreenStr
home_dir()

