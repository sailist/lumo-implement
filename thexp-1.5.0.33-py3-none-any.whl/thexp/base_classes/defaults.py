"""

"""


def draw_dict():
    res = dict()

    res['x'] = []
    res['y'] = []
    return res


class default():
    def __init__(self, default, warn=False):
        self.default = default
        self.warn = warn
