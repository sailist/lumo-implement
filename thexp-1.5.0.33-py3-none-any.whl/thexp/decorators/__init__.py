from .regist import regist_func
from .clsmethod import clswrap
from .deprecated import deprecated, warn
