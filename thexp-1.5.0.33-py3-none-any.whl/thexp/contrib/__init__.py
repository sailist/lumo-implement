"""
    包含众多对 torch 官方提供的方法或类的扩充
"""
from .module.ema import EMA
from .optim.grouper import ParamGrouper
