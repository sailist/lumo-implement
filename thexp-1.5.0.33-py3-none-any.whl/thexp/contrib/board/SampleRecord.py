"""

record.mark_acc(id,True)/mark_pred(id,pred)

...

"""